<?php
// Database configuration
define('DB_HOST', 'rs8-fra.serverhostgroup.com');
define('DB_USER', 'johnmogi_sunlightUSER');
define('DB_PASS', 'bG5Y!1gAy&rf9nO!#n80FkX');
define('DB_NAME', 'johnmogi_sunlightLP');

// Timezone
date_default_timezone_set('UTC');
?>
